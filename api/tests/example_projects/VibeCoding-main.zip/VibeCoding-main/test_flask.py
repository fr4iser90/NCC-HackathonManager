from flask import Flask
print("Flask imported successfully!")

app = Flask(__name__)
print("Flask instance created successfully!") 