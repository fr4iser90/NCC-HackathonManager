# Backend for SecuLite v2

This directory contains the Django backend application. 